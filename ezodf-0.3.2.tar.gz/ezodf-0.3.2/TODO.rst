
TODO
====

Version 0.1.0
-------------

  * Pre-Alpha
  * open/rewrite odf files, no data manipulation like add, delete or modify
  * basic docs http://packages.python.org/ezodf/
  * basic common style management
  * modify metadata

Version 0.2.0
-------------

  * Alpha
  * odt - application/vnd.oasis.opendocument.text

Version 0.2.1
-------------

  * Alpha
  * ods - application/vnd.oasis.opendocument.spreadsheet

Version 0.2.2
-------------

  * Alpha
  * odg - application/vnd.oasis.opendocument.graphics

Version 0.2.3
-------------

  * Alpha
  * odp - application/vnd.oasis.opendocument.presentation

Version 0.2.4
-------------

  * Beta
  * basic style management

Version 0.3.0
-------------

  * Simple Variables and User Fields handling
  * Full python 2.6 support
  * Tests moved to tox
