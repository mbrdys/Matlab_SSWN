version = (0, 3, 2)
VERSION = '%d.%d.%d' % version
